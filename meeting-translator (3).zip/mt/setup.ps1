﻿<#
  setup.ps1 - 会議用ローカル翻訳環境のセットアップ（初回に1回だけ実行）

  実行方法（このフォルダで PowerShell を開いて）:
    Set-ExecutionPolicy -Scope Process Bypass
    .\setup.ps1

  オプション:
    -SkipInstall   アプリのインストールを省略（モデルの準備だけやり直す時）
    -NoProxy       Python と翻訳プロキシを使わない（Qwen / Gemma だけで運用する時。PLaMo は使えない）
    -Models        取得するモデル（既定: PLaMo 3 Translate 2B / TranslateGemma 4B / Qwen3.5 4B）
    -Proxy         社内プロキシのアドレス（例: http://proxy.example.co.jp:8080）。
                   省略時は Windows のプロキシ設定を自動で使う。このスクリプトの実行中だけ有効
    -PlamoGguf     ブラウザで手動ダウンロードした PLaMo の GGUF ファイルから作成する（Ollama が取得できない時）

  例:
    .\setup.ps1 -Proxy http://proxy.example.co.jp:8080
    .\setup.ps1 -SkipInstall -PlamoGguf $HOME\Downloads\plamo-3-translate-2b-Q4_K_M.gguf
    .\setup.ps1 -SkipInstall -Models hf.co/pfnet/plamo-3-translate-0.8b-GGUF:Q4_K_M   # PLaMo 0.8B を追加
#>
param(
    [switch]$SkipInstall,
    [switch]$NoProxy,
    [string[]]$Models = @('hf.co/pfnet/plamo-3-translate-2b-GGUF:Q4_K_M', 'translategemma:4b', 'qwen3.5:4b'),
    [string]$Proxy,
    [string]$PlamoGguf
)

# 外部コマンド（winget/ollama）の進捗表示でスクリプトが止まらないよう Continue にする
$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Set-Location $PSScriptRoot

# このスクリプト自身の通信（Invoke-RestMethod）は PC 内の Ollama だけなので、社内プロキシを使わない
[Net.WebRequest]::DefaultWebProxy = New-Object Net.WebProxy
try { [Net.Http.HttpClient]::DefaultProxy = New-Object Net.WebProxy } catch { }

# 元モデル → 会議用に設定を固定したモデル。Modelfile の FROM 行は取得したモデル名に置き換えて作成する
$CustomModels = @(
    @{ Match = 'plamo-3-translate-0.8b'; Name = 'mt-plamo-08'; File = 'Modelfile.plamo' },
    @{ Match = 'plamo-3-translate-2b';   Name = 'mt-plamo';    File = 'Modelfile.plamo' },
    @{ Match = 'plamo-3-translate-8b';   Name = 'mt-plamo-8b'; File = 'Modelfile.plamo' },
    @{ Match = 'translategemma';         Name = 'mt-tg';       File = 'Modelfile.translategemma' },
    @{ Match = 'qwen3.5';                Name = 'mt-qwen';     File = 'Modelfile.qwen' },
    @{ Match = 'gemma4';                 Name = 'mt-gemma';    File = 'Modelfile.gemma' }
)

function Step($msg) { Write-Host "`n=== $msg ===" -ForegroundColor Cyan }
function Ok($msg)   { Write-Host "  OK  $msg" -ForegroundColor Green }
function Warn($msg) { Write-Host "  !!  $msg" -ForegroundColor Yellow }

function Update-PathFromRegistry {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user    = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machine;$user"
}

function Test-OllamaApi {
    try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/version' -TimeoutSec 3 | Out-Null; return $true }
    catch { return $false }
}

function Start-OllamaApp {
    # このセッションの環境変数（HTTPS_PROXY など）を引き継いで起動する
    $app = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama app.exe'
    if (Test-Path $app) { Start-Process $app } else { Start-Process 'ollama' -ArgumentList 'serve' -WindowStyle Hidden }
    for ($i = 0; $i -lt 30; $i++) {
        if (Test-OllamaApi) { return }
        Start-Sleep -Seconds 1
    }
    throw 'Ollama が起動しません。スタートメニューから Ollama を起動してから再実行してください。'
}

function Find-CustomModel([string]$model) {
    foreach ($c in $CustomModels) {
        if ($model.ToLower().Contains($c.Match)) { return $c }
    }
    return $null
}

function New-MeetingModel([string]$from, $c) {
    # Modelfile の FROM 行を置き換えて ollama create する
    $tmp = Join-Path $env:TEMP "Modelfile.$($c.Name)"
    $lines = Get-Content $c.File -Encoding UTF8 | ForEach-Object { if ($_ -match '^\s*FROM\s') { "FROM $from" } else { $_ } }
    [IO.File]::WriteAllLines($tmp, [string[]]$lines, (New-Object Text.UTF8Encoding($false)))
    ollama create $c.Name -f $tmp
    $ok = ($LASTEXITCODE -eq 0)
    Remove-Item $tmp -ErrorAction SilentlyContinue
    return $ok
}

function Get-SystemProxy {
    # Windows のプロキシ設定（設定 > ネットワークとインターネット > プロキシ）を読む
    $is = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction SilentlyContinue
    $server = $null
    if ($is.ProxyEnable -eq 1 -and $is.ProxyServer) {
        $s = [string]$is.ProxyServer
        if ($s -match '(^|;)https=([^;]+)')     { $server = $Matches[2] }
        elseif ($s -match '(^|;)http=([^;]+)')  { $server = $Matches[2] }
        elseif ($s -notmatch '=')               { $server = $s }
        if ($server -and $server -notmatch '^[a-z]+://') { $server = "http://$server" }
    }
    return [pscustomobject]@{ Server = $server; Pac = $is.AutoConfigURL }
}

# ---------------------------------------------------------------
Step '1. Windows のバージョン確認'
$build = [int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').CurrentBuildNumber
if ($build -lt 22621) { throw "ライブキャプションには Windows 11 22H2（ビルド 22621）以降が必要です。現在のビルド: $build" }
Ok "ビルド $build"

if ($PlamoGguf) {
    if (-not (Test-Path $PlamoGguf)) { throw "GGUF ファイルが見つかりません: $PlamoGguf" }
    $PlamoGguf = (Resolve-Path $PlamoGguf).Path
    $Models = @($Models | Where-Object { $_ -notmatch 'plamo' })   # PLaMo はダウンロードせず、手元のファイルから作る
}

$usePlamo = $PlamoGguf -or (@($Models | Where-Object { $_ -match 'plamo' }).Count -gt 0)
if ($usePlamo) {
    Write-Host @"

  [ライセンス確認] PLaMo 3 Translate は PLaMo Community License です。
    ・個人 / 非商用利用：無料・登録不要
    ・商用利用（業務の会議を含む）：直近年度の売上が10億円以下なら、PFN の登録フォーム提出で無料
    ・売上が10億円を超える会社：別途ライセンス契約が必要
  会社で使う場合は、事前に社内の担当部署に確認してください。
"@ -ForegroundColor Yellow
    if ($NoProxy) { Warn 'PLaMo は翻訳プロキシ（Python）が必要です。-NoProxy を外して実行してください。' }
}

# ---------------------------------------------------------------
Step '2. 社内プロキシの確認（ダウンロード用）'
$sys = Get-SystemProxy

# Cisco Secure Client（Cisco Secure Access / SSE）の検出
$cisco = @("${env:ProgramFiles(x86)}\Cisco\Cisco Secure Client", "$env:ProgramFiles\Cisco\Cisco Secure Client") |
    Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if ($cisco) {
    Ok 'Cisco Secure Client を検出しました。インターネット宛ての通信は自動で Cisco Secure Access を経由します。'
    $ca = @(Get-ChildItem Cert:\LocalMachine\Root, Cert:\CurrentUser\Root -ErrorAction SilentlyContinue |
        Where-Object { $_.Subject -match 'Cisco|Umbrella|Secure Access' })
    if ($ca.Count -gt 0) { Ok "Cisco のルート証明書あり（$($ca[0].Subject)）" }
    else { Warn 'Cisco のルート証明書が見つかりません（会社独自の証明書の場合もあります）。証明書エラーが出たら IT部門に確認してください。' }
    Write-Host @"

  Okta の認証はブラウザでしか行えないため、Ollama のダウンロードには使われません。
  会社の設定によっては「直前にブラウザで認証した人の通信」として扱われるので、
  先にブラウザで Okta にサインインし、何かサイトを1つ開いてから続けてください。
"@ -ForegroundColor Yellow
    Read-Host '  準備ができたら Enter'
}

if (-not $Proxy -and $sys.Server) { $Proxy = $sys.Server; Ok "Windows のプロキシ設定を使います: $Proxy" }
if ($Proxy) {
    # Ollama のモデル取得は HTTPS_PROXY だけを使う（HTTP_PROXY は PC 内の通信を妨げるので設定しない）。
    # このスクリプトから起動した Ollama にだけ引き継がれ、Windows の設定は変更しない。
    $env:HTTPS_PROXY = $Proxy
    $env:NO_PROXY = 'localhost,127.0.0.1'
    Remove-Item Env:HTTP_PROXY -ErrorAction SilentlyContinue
    Ok "モデルのダウンロードに $Proxy を使います（このスクリプトの実行中のみ）"
    if ($Proxy -match '@') { Warn 'プロキシのアドレスにパスワードが含まれています。画面やログに残さないよう注意してください。' }
} elseif ($cisco) {
    Ok 'プロキシの指定は不要です（Cisco Secure Client が自動で経由させます）'
} elseif ($sys.Pac) {
    Warn "自動構成スクリプト（PAC: $($sys.Pac)）でプロキシが設定されています。Ollama はこれを読めません。"
    Warn 'ダウンロードに失敗したら、IT部門にプロキシのアドレスを確認し、-Proxy http://アドレス:ポート を付けて再実行してください。'
} else {
    Ok 'プロキシ設定なし（直接接続）'
}

# ---------------------------------------------------------------
if (-not $SkipInstall) {
    Step '3. アプリのインストール（winget）'
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        throw 'winget が見つかりません。Microsoft Store で「アプリ インストーラー」を更新するか、README の「手動インストール」の手順で入れてから -SkipInstall を付けて再実行してください。'
    }
    $packages = @(
        @{ Id = 'Ollama.Ollama';                      Label = 'Ollama（ローカルLLM）';                          Url = 'https://ollama.com/download/windows' },
        @{ Id = 'Microsoft.DotNet.DesktopRuntime.8';  Label = '.NET 8 デスクトップランタイム（Translator 用）'; Url = 'https://dotnet.microsoft.com/download/dotnet/8.0' }
    )
    if (-not $NoProxy) { $packages += @{ Id = 'Python.Python.3.12'; Label = 'Python 3.12（翻訳プロキシ用）'; Url = 'https://www.python.org/downloads/windows/' } }

    $failed = @()
    foreach ($p in $packages) {
        winget list --id $p.Id -e --accept-source-agreements *> $null
        if ($LASTEXITCODE -eq 0) { Ok "$($p.Label) はインストール済み"; continue }
        Write-Host "  インストール中: $($p.Label)"
        winget install --id $p.Id -e --silent --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) { Warn "$($p.Label) のインストールに失敗しました（コード $LASTEXITCODE）"; $failed += $p }
        else { Ok $p.Label }
    }
    if ($failed.Count -gt 0) {
        Write-Host "`n  社内プロキシで winget がブロックされている可能性があります。ブラウザで次から入れてください:" -ForegroundColor Yellow
        $failed | ForEach-Object { Write-Host "    $($_.Label): $($_.Url)" -ForegroundColor Yellow }
        Write-Host '  入れ終わったら、PowerShell を開き直して .\setup.ps1 -SkipInstall を実行してください。' -ForegroundColor Yellow
        if (@($failed | Where-Object { $_.Id -eq 'Ollama.Ollama' }).Count -gt 0) { exit 1 }
    }
    Update-PathFromRegistry
}

# ---------------------------------------------------------------
Step '4. Ollama の設定（環境変数）'
# 同時に1件だけ処理（CPU の取り合いを防ぐ）、メモリに載せるモデルは1つだけ
[Environment]::SetEnvironmentVariable('OLLAMA_NUM_PARALLEL', '1', 'User')
[Environment]::SetEnvironmentVariable('OLLAMA_MAX_LOADED_MODELS', '1', 'User')
[Environment]::SetEnvironmentVariable('OLLAMA_KEEP_ALIVE', '60m', 'User')
$env:OLLAMA_NUM_PARALLEL = '1'; $env:OLLAMA_MAX_LOADED_MODELS = '1'; $env:OLLAMA_KEEP_ALIVE = '60m'
Ok 'OLLAMA_NUM_PARALLEL=1 / OLLAMA_MAX_LOADED_MODELS=1 / OLLAMA_KEEP_ALIVE=60m'

$hostVar = [Environment]::GetEnvironmentVariable('OLLAMA_HOST', 'User') + [Environment]::GetEnvironmentVariable('OLLAMA_HOST', 'Machine')
if ($hostVar -match '0\.0\.0\.0|::') {
    Warn "OLLAMA_HOST=$hostVar になっています。社内ネットワークから Ollama に接続できてしまうので、削除を推奨します。"
} else { Ok 'Ollama は 127.0.0.1 のみで待ち受け（OLLAMA_HOST 未設定）' }

# 設定（とプロキシ）を反映させるため、このセッションから Ollama を起動し直す
Get-Process -Name 'ollama*' -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2
if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) { Update-PathFromRegistry }
Start-OllamaApp
Ok "Ollama 起動（バージョン $((Invoke-RestMethod 'http://127.0.0.1:11434/api/version').version)）"

# ---------------------------------------------------------------
Step '5. モデルのダウンロードと会議用モデルの作成'
$pullFailed = $false
foreach ($m in $Models) {
    Write-Host "  取得中: $m（初回は数GBのダウンロードがあります）"
    ollama pull $m
    if ($LASTEXITCODE -ne 0) {
        $pullFailed = $true
        # 失敗の理由を判別するため、もう一度だけ実行してエラー文を取得（失敗時はすぐ終わる）
        $text = (cmd /c "ollama pull $m 2>&1") | Out-String
        if ($text -match 'x509|certificate') {
            if ($cisco) { Warn "${m}: 証明書エラー。Cisco Secure Access が通信を復号していて、その証明書を Ollama が信頼できていません。IT部門に、復号用ルート証明書の配布か、ダウンロード先ドメインの復号除外を依頼してください。" }
            else { Warn "${m}: 証明書エラー。社内プロキシが通信を検査している可能性があります（README「社内プロキシ」参照）。" }
        } elseif ($text -match 'proxy|407|tcp|dial|timeout|connection|forbidden|403|blocked') {
            if ($cisco) { Warn "${m}: 接続エラー。Cisco Secure Access のポリシー（AI関連カテゴリの制限、未認証の通信の拒否など）でブロックされた可能性があります。ブラウザで Okta 認証した直後に再実行し、それでもだめなら IT部門に許可を依頼してください。" }
            else { Warn "${m}: 接続エラー。プロキシのアドレスや認証の有無、接続先が許可されているかを確認してください（README「社内プロキシ」参照）。" }
        } else {
            Warn "$m を取得できませんでした。モデル名を確認し、Ollama を最新版に更新してください（winget upgrade Ollama.Ollama）。"
        }
        continue
    }

    $c = Find-CustomModel $m
    if (-not $c -or -not (Test-Path $c.File)) { Ok "$m（会議用モデルの定義なし。そのまま使えます）"; continue }
    if (New-MeetingModel $m $c) { Ok "$m → $($c.Name)" } else { Warn "$($c.Name) の作成に失敗しました" }
}

if ($PlamoGguf) {
    $c = Find-CustomModel (Split-Path $PlamoGguf -Leaf)
    if (-not $c -or $c.File -ne 'Modelfile.plamo') { $c = Find-CustomModel 'plamo-3-translate-2b' }
    Write-Host "  手元のファイルから作成: $PlamoGguf"
    if (New-MeetingModel $PlamoGguf $c) { Ok "$(Split-Path $PlamoGguf -Leaf) → $($c.Name)" } else { Warn "$($c.Name) の作成に失敗しました" }
}

if ($pullFailed) {
    Write-Host @"

  取得できなかったモデルがあります。対処（詳しくは README の「社内プロキシ」）:
    ・プロキシのアドレスを指定して再実行:  .\setup.ps1 -SkipInstall -Proxy http://アドレス:ポート
    ・PLaMo は、ブラウザで GGUF をダウンロードして作成:  .\setup.ps1 -SkipInstall -PlamoGguf <ファイルのパス>
"@ -ForegroundColor Yellow
}

# ---------------------------------------------------------------
if (-not $NoProxy) {
    Step '6. Python の確認'
    $py = Get-Command py -ErrorAction SilentlyContinue
    if (-not $py) { $py = Get-Command python -ErrorAction SilentlyContinue }
    if ($py) { Ok "$(& $py.Source --version 2>&1)" }
    else { Warn 'Python が見つかりません。PowerShell を開き直すか、Python をインストールしてください。' }
}

Write-Host "`nセットアップ完了。次は bench.ps1 でモデルを比較してください。" -ForegroundColor Cyan
Write-Host '  .\bench.ps1'
