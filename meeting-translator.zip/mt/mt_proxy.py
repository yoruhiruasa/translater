"""
mt_proxy.py - LiveCaptions-Translator と Ollama の間に入るローカル専用プロキシ

役割:
  1. TranslateGemma 用に、正しいプロンプト形式へ書き換える（--mode tg）
  2. 話している途中の「古い」翻訳要求を捨て、最新の1件だけを CPU で処理する
  3. ライブキャプションの決まった聞き間違いを、翻訳前に置換する（--fix）
  4. Ollama の応答を Translator が読み込める形に整える

LiveCaptions-Translator 側の設定:
  Translate API = Ollama / API URL = http://127.0.0.1:11500 / Model = 何でもよい

標準ライブラリだけで動きます（pip install 不要）。
待ち受けは 127.0.0.1 のみ。外部への通信は行いません。
"""
import argparse
import json
import re
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# TranslateGemma が想定するプロンプト形式（Ollama のモデルページ記載の形式。テキスト前は空行2つ）
TG_TEMPLATE = (
    "You are a professional {sl} ({sc}) to {tl} ({tc}) translator. "
    "Your goal is to accurately convey the meaning and nuances of the original {sl} text "
    "while adhering to {tl} grammar, vocabulary, and cultural sensitivities.\n"
    "Produce only the {tl} translation, without any additional explanations or commentary. "
    "Please translate the following {sl} text into {tl}:\n\n\n{text}"
)
LANG_NAMES = {"en": "English", "ja": "Japanese"}
MARKER = "\U0001F524"  # Translator が原文を囲む 🔤

state = {"latest": 0, "last_src": None, "last_resp": None, "skipped": 0, "done": 0}
state_lock = threading.Lock()   # state の読み書き用
gen_lock = threading.Lock()     # 生成は常に1件ずつ（CPU の取り合いを防ぐ）
args = None
fixes = []


def log(msg):
    if not args.quiet:
        print(f"[{datetime.now():%H:%M:%S}] {msg}", flush=True)


def load_fixes(path):
    """TSV: 聞き間違い<TAB>正しい語。# で始まる行はコメント。大文字小文字は区別しない。"""
    rules = []
    with open(path, encoding="utf-8-sig") as f:
        for line in f:
            line = line.rstrip("\r\n")
            if not line.strip() or line.lstrip().startswith("#") or "\t" not in line:
                continue
            wrong, right = line.split("\t", 1)
            rules.append((re.compile(r"\b" + re.escape(wrong.strip()) + r"\b", re.I), right.strip()))
    return rules


def apply_fixes(text):
    for pat, right in fixes:
        text = pat.sub(right, text)
    return text


def extract_source(messages):
    """Translator が送る最後の user メッセージから原文を取り出す。"""
    for m in reversed(messages or []):
        if m.get("role") == "user":
            return m.get("content", "").replace(MARKER, "").strip()
    return ""


def call_ollama(body):
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        args.upstream.rstrip("/") + "/api/chat", data=data,
        headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode("utf-8"))


def sanitize(resp):
    """Translator は load_duration を 32bit 整数で読むため、大きな値だと読み込みに失敗する。"""
    for k in ("load_duration",):
        if isinstance(resp.get(k), int) and resp[k] > 2_000_000_000:
            resp[k] = 0
    resp.setdefault("created_at", datetime.now(timezone.utc).isoformat())
    resp["done"] = True
    return resp


def make_response(content, base=None):
    resp = dict(base or {})
    resp["model"] = resp.get("model", args.model)
    resp["message"] = {"role": "assistant", "content": content}
    return sanitize(resp)


def translate(req_body):
    src = apply_fixes(extract_source(req_body.get("messages")))
    with state_lock:
        state["latest"] += 1
        my_id = state["latest"]

    if not src:
        return make_response("")

    with gen_lock:
        with state_lock:
            superseded = my_id != state["latest"]
            same_as_last = src == state["last_src"]
            last = state["last_resp"]
        # 待っている間に新しい要求が来ていたら、この（古い）要求は生成しない
        if (superseded or same_as_last) and last is not None:
            with state_lock:
                state["skipped"] += 1
            return last

        if args.mode == "tg":
            sl, tl = LANG_NAMES.get(args.src, args.src), LANG_NAMES.get(args.tgt, args.tgt)
            prompt = TG_TEMPLATE.format(sl=sl, sc=args.src, tl=tl, tc=args.tgt, text=src)
            body = {"model": args.model, "stream": False,
                    "messages": [{"role": "user", "content": prompt}]}
        else:  # passthrough: Translator のプロンプトをそのまま使い、モデル名だけ差し替え
            body = dict(req_body)
            body["stream"] = False
            body["model"] = args.model
            msgs = [dict(m) for m in body.get("messages", [])]
            for m in reversed(msgs):
                if m.get("role") == "user":
                    m["content"] = f"{MARKER} {src} {MARKER}"
                    break
            body["messages"] = msgs
            body.setdefault("think", False)

        body["keep_alive"] = args.keep_alive
        body["options"] = {"temperature": args.temperature, "num_predict": args.max_tokens}

        t0 = time.perf_counter()
        resp = call_ollama(body)
        dt = time.perf_counter() - t0
        out = (resp.get("message") or {}).get("content", "").replace(MARKER, "").strip()
        result = make_response(out, resp)

        with state_lock:
            state["last_src"], state["last_resp"] = src, result
            state["done"] += 1
        tok = resp.get("eval_count") or 0
        ev = (resp.get("eval_duration") or 0) / 1e9
        rate = f"{tok / ev:.1f} tok/s" if ev else "-"
        warn = "  ※8秒超: Translator側でタイムアウトします" if dt > 8 else ""
        log(f"{dt:4.1f}s {rate:>11} | {src[:70]}  →  {out[:60]}{warn}")
        return result


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):  # 標準のアクセスログは出さない
        pass

    def _send(self, code, payload, ctype="application/json; charset=utf-8"):
        data = payload if isinstance(payload, bytes) else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass  # Translator 側が古い要求を取り消した

    def _forward(self, method, body=None):
        req = urllib.request.Request(args.upstream.rstrip("/") + self.path, data=body, method=method,
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                self._send(r.status, r.read(), r.headers.get("Content-Type", "application/json"))
        except urllib.error.HTTPError as e:
            self._send(e.code, e.read())
        except Exception as e:
            self._send(502, {"error": str(e)})

    def do_GET(self):
        if self.path == "/proxy/status":
            with state_lock:
                self._send(200, {"mode": args.mode, "model": args.model,
                                 "translated": state["done"], "skipped": state["skipped"]})
            return
        self._forward("GET")

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b""
        if self.path.rstrip("/") != "/api/chat":
            self._forward("POST", raw)
            return
        try:
            body = json.loads(raw.decode("utf-8") or "{}")
            self._send(200, translate(body))
        except urllib.error.URLError as e:
            log(f"Ollama に接続できません: {e}")
            self._send(502, {"error": f"ollama unreachable: {e}"})
        except Exception as e:
            log(f"エラー: {e!r}")
            self._send(500, {"error": str(e)})


def main():
    global args, fixes
    p = argparse.ArgumentParser(description="LiveCaptions-Translator 用ローカル翻訳プロキシ")
    p.add_argument("--mode", choices=["tg", "passthrough"], default="tg",
                   help="tg: TranslateGemma形式に変換 / passthrough: Translatorのプロンプトをそのまま使う")
    p.add_argument("--model", default="mt-tg", help="Ollama のモデル名（既定: mt-tg）")
    p.add_argument("--port", type=int, default=11500)
    p.add_argument("--upstream", default="http://127.0.0.1:11434", help="Ollama の URL")
    p.add_argument("--src", default="en")
    p.add_argument("--tgt", default="ja")
    p.add_argument("--temperature", type=float, default=0.1)
    p.add_argument("--max-tokens", type=int, default=200)
    p.add_argument("--keep-alive", default="60m")
    p.add_argument("--fix", help="聞き間違い置換表（TSV）のパス")
    p.add_argument("--quiet", action="store_true", help="原文・訳文をコンソールに表示しない")
    args = p.parse_args()

    if args.fix:
        fixes = load_fixes(args.fix)

    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)  # ローカルのみ
    server.daemon_threads = True
    print(f"mt_proxy: http://127.0.0.1:{args.port}  →  {args.upstream}  "
          f"(mode={args.mode}, model={args.model}, 置換ルール={len(fixes)}件)")
    print("Translator の API URL にこのアドレスを設定してください。Ctrl+C で終了。", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n終了します。")
        sys.exit(0)


if __name__ == "__main__":
    main()
