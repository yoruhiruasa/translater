﻿<#
  setup.ps1 - 会議用ローカル翻訳環境のセットアップ（初回に1回だけ実行）

  実行方法（このフォルダで PowerShell を開いて）:
    Set-ExecutionPolicy -Scope Process Bypass
    .\setup.ps1

  オプション:
    -SkipInstall   アプリのインストールを省略（モデルの準備だけやり直す時）
    -NoProxy       Python と翻訳プロキシを使わない（qwen/gemma だけで運用する時）
    -Models        取得するモデル（既定: TranslateGemma 4B / Qwen3.5 4B / Gemma 4 E2B）
#>
param(
    [switch]$SkipInstall,
    [switch]$NoProxy,
    [string[]]$Models = @('translategemma:4b', 'qwen3.5:4b', 'gemma4:e2b')
)

# 外部コマンド（winget/ollama）の進捗表示でスクリプトが止まらないよう Continue にする
$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Set-Location $PSScriptRoot

# 元モデル → 会議用に設定を固定したモデル（Modelfile）
$CustomModels = @{
    'translategemma:4b' = @{ Name = 'mt-tg';    File = 'Modelfile.translategemma' }
    'qwen3.5:4b'        = @{ Name = 'mt-qwen';  File = 'Modelfile.qwen' }
    'gemma4:e2b'        = @{ Name = 'mt-gemma'; File = 'Modelfile.gemma' }
}

function Step($msg) { Write-Host "`n=== $msg ===" -ForegroundColor Cyan }
function Ok($msg)   { Write-Host "  OK  $msg" -ForegroundColor Green }
function Warn($msg) { Write-Host "  !!  $msg" -ForegroundColor Yellow }

function Update-PathFromRegistry {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user    = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machine;$user"
}

function Test-OllamaApi {
    try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/version' -TimeoutSec 3 | Out-Null; return $true }
    catch { return $false }
}

function Start-OllamaApp {
    $app = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama app.exe'
    if (Test-Path $app) { Start-Process $app } else { Start-Process 'ollama' -ArgumentList 'serve' -WindowStyle Hidden }
    for ($i = 0; $i -lt 30; $i++) {
        if (Test-OllamaApi) { return }
        Start-Sleep -Seconds 1
    }
    throw 'Ollama が起動しません。スタートメニューから Ollama を起動してから再実行してください。'
}

# ---------------------------------------------------------------
Step '1. Windows のバージョン確認'
$build = [int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').CurrentBuildNumber
if ($build -lt 22621) { throw "ライブキャプションには Windows 11 22H2（ビルド 22621）以降が必要です。現在のビルド: $build" }
Ok "ビルド $build"

# ---------------------------------------------------------------
if (-not $SkipInstall) {
    Step '2. アプリのインストール（winget）'
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        throw 'winget が見つかりません。Microsoft Store で「アプリ インストーラー」を更新してから再実行してください。'
    }
    $packages = @(
        @{ Id = 'Ollama.Ollama';                      Label = 'Ollama（ローカルLLM）' },
        @{ Id = 'Microsoft.DotNet.DesktopRuntime.8';  Label = '.NET 8 デスクトップランタイム（Translator 用）' }
    )
    if (-not $NoProxy) { $packages += @{ Id = 'Python.Python.3.12'; Label = 'Python 3.12（翻訳プロキシ用）' } }

    foreach ($p in $packages) {
        winget list --id $p.Id -e --accept-source-agreements *> $null
        if ($LASTEXITCODE -eq 0) { Ok "$($p.Label) はインストール済み"; continue }
        Write-Host "  インストール中: $($p.Label)"
        winget install --id $p.Id -e --silent --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) { Warn "$($p.Label) のインストールに失敗した可能性があります（コード $LASTEXITCODE）" }
        else { Ok $p.Label }
    }
    Update-PathFromRegistry
}

# ---------------------------------------------------------------
Step '3. Ollama の設定（環境変数）'
# 同時に1件だけ処理（CPU の取り合いを防ぐ）、メモリに載せるモデルは1つだけ
[Environment]::SetEnvironmentVariable('OLLAMA_NUM_PARALLEL', '1', 'User')
[Environment]::SetEnvironmentVariable('OLLAMA_MAX_LOADED_MODELS', '1', 'User')
[Environment]::SetEnvironmentVariable('OLLAMA_KEEP_ALIVE', '60m', 'User')
$env:OLLAMA_NUM_PARALLEL = '1'; $env:OLLAMA_MAX_LOADED_MODELS = '1'; $env:OLLAMA_KEEP_ALIVE = '60m'
Ok 'OLLAMA_NUM_PARALLEL=1 / OLLAMA_MAX_LOADED_MODELS=1 / OLLAMA_KEEP_ALIVE=60m'

$hostVar = [Environment]::GetEnvironmentVariable('OLLAMA_HOST', 'User') + [Environment]::GetEnvironmentVariable('OLLAMA_HOST', 'Machine')
if ($hostVar -match '0\.0\.0\.0|::') {
    Warn "OLLAMA_HOST=$hostVar になっています。社内ネットワークから Ollama に接続できてしまうので、削除を推奨します。"
} else { Ok 'Ollama は 127.0.0.1 のみで待ち受け（OLLAMA_HOST 未設定）' }

# 設定を反映させるため Ollama を再起動
Get-Process -Name 'ollama*' -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2
if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) { Update-PathFromRegistry }
Start-OllamaApp
Ok "Ollama 起動（バージョン $((Invoke-RestMethod 'http://127.0.0.1:11434/api/version').version)）"

# ---------------------------------------------------------------
Step '4. モデルのダウンロードと会議用モデルの作成'
foreach ($m in $Models) {
    Write-Host "  取得中: $m（初回は数GBのダウンロードがあります）"
    ollama pull $m
    if ($LASTEXITCODE -ne 0) { Warn "$m を取得できませんでした。モデル名が変わっていないか ollama.com で確認してください。"; continue }

    $c = $CustomModels[$m]
    if ($c -and (Test-Path $c.File)) {
        ollama create $c.Name -f $c.File
        if ($LASTEXITCODE -eq 0) { Ok "$m → $($c.Name)" } else { Warn "$($c.Name) の作成に失敗しました" }
    }
}

# ---------------------------------------------------------------
if (-not $NoProxy) {
    Step '5. Python の確認'
    $py = Get-Command py -ErrorAction SilentlyContinue
    if (-not $py) { $py = Get-Command python -ErrorAction SilentlyContinue }
    if ($py) { Ok "$(& $py.Source --version 2>&1)" }
    else { Warn 'Python が見つかりません。PowerShell を開き直すか、Python をインストールしてください。' }
}

Write-Host "`nセットアップ完了。次は bench.ps1 でモデルを比較してください。" -ForegroundColor Cyan
Write-Host '  .\bench.ps1'
