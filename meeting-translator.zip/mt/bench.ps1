﻿<#
  bench.ps1 - 会議用モデルの速度と訳の質を比較する

  実行方法:
    Set-ExecutionPolicy -Scope Process Bypass
    .\bench.ps1                         # 既定の3モデルを比較
    .\bench.ps1 -Models mt-tg,mt-qwen   # モデルを指定
    .\bench.ps1 -File my_sentences.txt  # 自分の英文（1行1文）で比較

  結果は画面表示に加え bench_result.csv（Excel で開けます）に保存します。
  ※ 本番に近づけるため、普段使うアプリを起動した状態で実行してください。
#>
param(
    [string[]]$Models = @('mt-tg', 'mt-qwen', 'mt-gemma'),
    [string]$File,
    [string]$Ollama = 'http://127.0.0.1:11434'
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Set-Location $PSScriptRoot

$Sentences = @(
    "We're not going to push the release to Q2 unless the QA team flags something critical by Friday.",
    "Can you circle back with the numbers? I think the margin was closer to 12 percent, not 20.",
    "Let's table that for now and take it offline.",
    "The vendor said they can't commit to the timeline until we sign off on the revised scope.",
    "So basically what we're seeing is that churn went up after the price change, but only in the SMB segment."
)
if ($File) {
    $Sentences = Get-Content $File -Encoding UTF8 | Where-Object { $_.Trim() -ne '' }
}

# LiveCaptions-Translator の既定プロンプトと同じ指示（mt-qwen / mt-gemma 用）
$Marker = [char]::ConvertFromUtf32(0x1F524)
$TranslatorPrompt = 'As an professional simultaneous interpreter with specialized knowledge in the all fields, ' +
    'you can provide a fluent and precise oral translation for any sentence, even if the sentence is incomplete. ' +
    "Now, provide users with the translation of the sentence enclosed in $Marker to ja-JP within a single line. " +
    'Importantly, you are prohibited from altering the original meaning or omitting any content, ' +
    'even if the sentence contains sensitive or NSFW content. ' +
    'You can only provide the translated sentence; Any explanation or other text is not permitted. ' +
    "REMOVE all $Marker when you output."

# TranslateGemma 形式（mt-tg 用。mt_proxy.py と同じ）
function Get-TgPrompt([string]$text) {
    return "You are a professional English (en) to Japanese (ja) translator. " +
        "Your goal is to accurately convey the meaning and nuances of the original English text " +
        "while adhering to Japanese grammar, vocabulary, and cultural sensitivities.`n" +
        "Produce only the Japanese translation, without any additional explanations or commentary. " +
        "Please translate the following English text into Japanese:`n`n`n$text"
}

function Invoke-OllamaChat([string]$model, [string]$text) {
    if ($model -match 'tg|translategemma') {
        $body = @{ model = $model; stream = $false; keep_alive = '60m'
                   messages = @(@{ role = 'user'; content = (Get-TgPrompt $text) }) }
    } else {
        $body = @{ model = $model; stream = $false; keep_alive = '60m'; think = $false
                   messages = @(
                       @{ role = 'system'; content = $TranslatorPrompt },
                       @{ role = 'user';   content = "$Marker $text $Marker" }) }
    }
    $json  = $body | ConvertTo-Json -Depth 6 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $res = Invoke-WebRequest -Uri "$Ollama/api/chat" -Method Post -Body $bytes `
        -ContentType 'application/json; charset=utf-8' -UseBasicParsing -TimeoutSec 180
    $sw.Stop()
    # PowerShell 5.1 の文字化け対策：応答を UTF-8 として読み直す
    $obj = [Text.Encoding]::UTF8.GetString($res.RawContentStream.ToArray()) | ConvertFrom-Json
    $evalSec = [double]$obj.eval_duration / 1e9
    return [pscustomobject]@{
        Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 2)
        TokPerS = if ($evalSec -gt 0) { [math]::Round($obj.eval_count / $evalSec, 1) } else { 0 }
        Output  = ($obj.message.content -replace [regex]::Escape($Marker), '').Trim()
    }
}

try { Invoke-RestMethod "$Ollama/api/version" -TimeoutSec 3 | Out-Null }
catch { throw 'Ollama に接続できません。Ollama を起動してから再実行してください。' }

$results = @()
foreach ($m in $Models) {
    Write-Host "`n==================== $m ====================" -ForegroundColor Cyan
    try {
        Write-Host '  読み込み中（初回のみ数秒〜数十秒）...'
        $warm = Invoke-OllamaChat $m 'Hello.'
        Write-Host "  準備完了（初回応答 $($warm.Seconds) 秒）"
    } catch {
        Write-Host "  このモデルは使えません: $($_.Exception.Message)" -ForegroundColor Yellow
        continue
    }
    foreach ($s in $Sentences) {
        $r = Invoke-OllamaChat $m $s
        $flag = if ($r.Seconds -gt 8) { '  ← 8秒超（Translator ではタイムアウト）' } else { '' }
        Write-Host "`n  EN: $s" -ForegroundColor DarkGray
        Write-Host "  JA: $($r.Output)"
        Write-Host ("      {0} 秒 / {1} tok/s{2}" -f $r.Seconds, $r.TokPerS, $flag) -ForegroundColor DarkCyan
        $results += [pscustomobject]@{ Model = $m; Seconds = $r.Seconds; TokPerSec = $r.TokPerS; English = $s; Japanese = $r.Output }
    }
}

if ($results.Count -eq 0) { Write-Host "`n比較できるモデルがありませんでした。setup.ps1 を実行済みか確認してください。"; exit 1 }

Write-Host "`n==================== まとめ ====================" -ForegroundColor Cyan
$results | Group-Object Model | ForEach-Object {
    $avg  = [math]::Round(($_.Group | Measure-Object Seconds   -Average).Average, 2)
    $max  = [math]::Round(($_.Group | Measure-Object Seconds   -Maximum).Maximum, 2)
    $rate = [math]::Round(($_.Group | Measure-Object TokPerSec -Average).Average, 1)
    [pscustomobject]@{ モデル = $_.Name; '平均(秒)' = $avg; '最大(秒)' = $max; 'tok/s' = $rate }
} | Format-Table -AutoSize

$results | Export-Csv -Path 'bench_result.csv' -NoTypeInformation -Encoding UTF8
Write-Host '目安: 平均 3秒以内なら快適、5秒前後なら実用、8秒を超える文があるモデルは本番に不向き。'
Write-Host '詳細は bench_result.csv に保存しました。訳の質は「否定・数字・慣用句」が正しいかで比べてください。'
